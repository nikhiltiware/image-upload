Cloudinary Photo Album Sample
=======================================

