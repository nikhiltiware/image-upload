photoAlbumApp.config(['cloudinaryProvider', function (cloudinaryProvider) {
  cloudinaryProvider
      .set("cloud_name", "dhfbyx8mm")
      .set("upload_preset", "imyicsee")
    .set("API_KEY","326515731249721")
  .set("API_SECRET","3C8mzfcQ7gfaqZIeWg1ZVyuVZvI")
}]);