photoAlbumApp.controller('controllerForReload', ['$scope','$rootScope', '$window', function($scope, $rootScope, $window) {
  $scope.greeting = 'Hola!';
    alert($scope.greeting);
}]);